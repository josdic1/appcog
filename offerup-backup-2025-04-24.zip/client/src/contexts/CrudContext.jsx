import { createContext } from "react";

const CrudContext = createContext()

export default CrudContext