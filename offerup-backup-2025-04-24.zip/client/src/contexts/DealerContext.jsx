import { createContext } from "react"

const DealerContext = createContext()

export default DealerContext