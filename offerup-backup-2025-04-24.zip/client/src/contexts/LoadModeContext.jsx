import { createContext } from "react";

    const LoadModeContext = createContext()

    export default LoadModeContext