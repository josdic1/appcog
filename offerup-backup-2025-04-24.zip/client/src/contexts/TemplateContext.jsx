import { createContext } from "react";

const TemplateContext = createContext()

export default TemplateContext