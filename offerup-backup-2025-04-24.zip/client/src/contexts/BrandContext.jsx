import { createContext } from "react"

const BrandContext = createContext()

export default BrandContext